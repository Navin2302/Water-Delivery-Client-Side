import React from 'react';
import {Image,Text,View} from 'react-native';

const Screen2=()=>
{
return(
  <View>
  <Text>Screen2</Text>
  </View>

);
};
 
export default Screen2;