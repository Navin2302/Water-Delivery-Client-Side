import React from 'react';
import {Image,Text,View} from 'react-native';
import BottomNavigator from './BottomNavigator';

const Main=()=>{
return(
  <View style={{flex:1}}>
<BottomNavigator/>
</View>
);

};

export default Main;